
//
//  GameScene.swift
//  CoffeeBreakDemo1
//
//  Created by Mario Di Marino on 30/01/21.
//

import Foundation
import SpriteKit
import AVFoundation



public class GameScene: SKScene, SKPhysicsContactDelegate{
    //let rectangle = SKSpriteNode(color: SKColor.cyan, size: CGSize(width: 750, height: 300))
    let checkflag = SKSpriteNode(imageNamed: "checkflag")
    let copen = SKSpriteNode(imageNamed: "copen")
    let copenCategory: UInt32 = 1
    let conoCategory: UInt32 = 2
    let recCategory: UInt32 = 3
    let arrowDx = SKSpriteNode(imageNamed: "arrow white")
    let arrowSx = SKSpriteNode(imageNamed: "arrow white")
    let background = SKSpriteNode(imageNamed: "asphalt")
    let front = SKSpriteNode(color: .red, size: CGSize(width: 25, height: 25))
    var leftPressed = false
    var rightPressed = false
    let copenRotateSpeed = 0.05
    let valore = 90
    var gameOver = false
    var gameWin = false
    var win = false
    var hit = false
    
    let triggerWin = SKSpriteNode(color: SKColor.red, size: CGSize(width: 750, height: 2))
    
    
    //    var sound: AVAudioPlayer?
    
    public override func didMove(to view: SKView) {
        
        background.position = CGPoint(x: 0, y: 0)
        background.zPosition = -1
        arrowDx.alpha = 0.8
        arrowSx.alpha = 0.8
        self.addChild(background)
        
        
        physicsWorld.contactDelegate = self
        //        MARK: dahiatsu copen
        copen.name  = "copen"
        copen.position = CGPoint(x: 0, y: -590)
        copen.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        copen.size = CGSize(width: 86, height: 136)
        copen.physicsBody = SKPhysicsBody(texture: copen.texture!, size: copen.texture!.size())
        copen.physicsBody?.friction = 0
        copen.physicsBody?.affectedByGravity = false
        copen.physicsBody?.isDynamic = true
        copen.physicsBody?.categoryBitMask = copenCategory
        copen.physicsBody?.contactTestBitMask = conoCategory + recCategory
        scene?.addChild(copen)
        
        //        MARK: HUD
        arrowDx.position = CGPoint(x: -230, y: -450)
        arrowDx.name = "arrowDx"
        arrowDx.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        arrowDx.size = CGSize(width: 230, height: 350)
        arrowDx.xScale = -1
        scene?.addChild(arrowDx)
        
        arrowSx.position = CGPoint(x: 230, y: -450)
        arrowSx.name = "arrowSx"
        arrowSx.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        arrowSx.size = CGSize(width: 230, height: 350)
        scene?.addChild(arrowSx)
        
        checkflag.position = CGPoint(x: 0, y: 540)
        checkflag.zPosition = -1
        checkflag.physicsBody?.categoryBitMask = recCategory
        checkflag.physicsBody?.contactTestBitMask = copenCategory
        scene?.addChild(checkflag)
        
        triggerWin.position = CGPoint(x:0, y:520)
        triggerWin.name = "trigger"
        triggerWin.alpha = 0
        triggerWin.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 750, height: 2))
        triggerWin.physicsBody?.affectedByGravity = false
        triggerWin.physicsBody?.categoryBitMask = recCategory
        triggerWin.physicsBody?.contactTestBitMask = copenCategory
        scene?.addChild(triggerWin)
        //         MARK: SPAWN DEI CONI
        spawnCono3()
    }
    
    
    
    //        MARK: COLLISION DETECTION
    public func didBegin(_ contact: SKPhysicsContact) {
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        var thirdBody: SKPhysicsBody
        if hit == false {
            if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask{
                firstBody = contact.bodyA
                secondBody = contact.bodyB
            }else{
                firstBody = contact.bodyB
                secondBody = contact.bodyA
            }
            //MARK: gameOer
            if (firstBody.categoryBitMask == copenCategory) && (secondBody.categoryBitMask == conoCategory) && (hit == false){
                gameOver = true
                copen.zPosition=98
                let overRec = SKShapeNode(rectOf: CGSize(width: 400, height: 300), cornerRadius: 50)
                overRec.fillColor = UIColor.black
                overRec.zPosition=99
                let overLabel = SKLabelNode()
                overLabel.text = "Game Over"
                overLabel.fontSize = 65
                overLabel.fontColor = UIColor.red
                overLabel.position = CGPoint(x: 0, y: 50)
                overLabel.zPosition = 99
                self.addChild(overRec)
                overRec.addChild(overLabel)
                hit = true
                scene?.run(SKAction.playSoundFileNamed("fail", waitForCompletion: true))
                scene?.run(SKAction.playSoundFileNamed("bonk", waitForCompletion: true))
                
            }
            //MARK: gameWin
            if (firstBody.categoryBitMask == copenCategory) && (secondBody.categoryBitMask == recCategory){
                let winRec = SKShapeNode(rectOf: CGSize(width: 400, height: 300), cornerRadius: 50)
                winRec.fillColor = UIColor.black
                winRec.zPosition=99
                let winLabel = SKLabelNode()
                winLabel.position = CGPoint(x:0,y:50)
                winLabel.text = "ciao"
                winLabel.fontSize = 65
                winLabel.fontColor = UIColor.green
                winLabel.zPosition = 99
                self.addChild(winRec)
                winRec.addChild(winLabel)
                scene?.run(SKAction.playSoundFileNamed("win", waitForCompletion: true))
                hit = true
            }
            
        }
        
        //          if ((firstBody.categoryBitMask & copenCategory != 0) && (secondBody.categoryBitMask & conoCategory != 0)) {
        //              gameOver = true
        //          }else if ((firstBody.categoryBitMask & copenCategory != 0) && (secondBody.categoryBitMask & recCategory != 0)) {
        //              let winLabel = SKLabelNode()
        //              winLabel.position = CGPoint(x:0.5,y:0.5)
//              winLabel.text = "ciao"
//              self.addChild(winLabel)
//          }
        
    }
    
    public func didEnd(_ contact: SKPhysicsContact) {
        
    }
    
    //    MARK: CONI
    func spawnCono3(){
        let textureA = SKTexture(imageNamed: "cono")
        
        let cono = SKSpriteNode(texture: textureA)
        let cono1 = cono.copy() as! SKSpriteNode
        cono.size = CGSize(width: 40, height: 40)
        cono.physicsBody = SKPhysicsBody(texture: cono.texture!, size: cono.texture!.size())
        cono.physicsBody?.affectedByGravity = false
        cono.physicsBody?.isDynamic = true
        cono.physicsBody?.categoryBitMask = conoCategory
        cono.physicsBody?.contactTestBitMask = copenCategory
        cono.physicsBody?.friction = 1
        cono.position = CGPoint(x: 0, y: 0)
        cono1.position = CGPoint(x: 100, y: 0)
        
        scene?.addChild(cono1)
        scene?.addChild(cono)
    }
    func spawnCono2(){}
    func spawnCono1(){
        for _ in 1...17{
            let textureA = SKTexture(imageNamed: "cono")
            let cono = SKSpriteNode(texture: textureA)
            cono.size = CGSize(width: 40, height: 40)
            
            cono.physicsBody = SKPhysicsBody(texture: cono.texture!, size: cono.texture!.size())
            cono.position = CGPoint(x:Int.random(in: -360...360) ,y: Int.random(in: -160...310))
            cono.physicsBody?.affectedByGravity = false
            cono.physicsBody?.isDynamic = true
            cono.physicsBody?.categoryBitMask = conoCategory
            cono.physicsBody?.contactTestBitMask = copenCategory
            cono.physicsBody?.friction = 1
            //            cono.physicsBody?.collisionBitMask = conoCategory
            scene?.addChild(cono)
        }
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
        if (node.name == "arrowDx") {
            leftPressed = true
        } else if (node.name == "arrowSx"){
            rightPressed = true
        }
        
    }
    
    public override func update(_ currentTime: TimeInterval) {
        //        MARK: DESTRA E SINISTRA
        if (leftPressed && rightPressed){
            //            nulla
        } else if (leftPressed){
            copen.zRotation += CGFloat(copenRotateSpeed)
        } else if (rightPressed){
            copen.zRotation -= CGFloat(copenRotateSpeed)
        }
        //        MARK: VELOCITA
        //        let rotation = copen.zRotation*180/3.14
        let dx = 200*(-sin(copen.zRotation))
        let dy = 200*(cos(copen.zRotation))
        //        copen.physicsBody?.applyImpulse(CGVector(dx: -sin(copen.zRotation)*3, dy: cos(copen.zRotation)*3))
        //        copen.physicsBody?.velocity = CGVector(dx: dx,dy: dy)
        //        print()
        //        MARK: GAMEOVER
        if (gameOver == false) {
            copen.physicsBody?.velocity = CGVector(dx: dx,dy: dy)
        } else if (gameOver == true) {
            copen.physicsBody?.velocity = CGVector(dx: 0,dy: 0)
            copen.zRotation -= CGFloat(copenRotateSpeed)
            arrowDx.removeFromParent()
            arrowSx.removeFromParent()
            copen.zPosition=99
        }
        //        MARK: WIN
        //if Int(copen.position.y)>520{
        //copen.physicsBody?.velocity = CGVector(dx: 0,dy: 0)
        //arrowDx.removeFromParent()
        //arrowSx.removeFromParent()
        //win = true
        //}
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first
        let touchLocation = touch!.location(in: self)
        let node = self.atPoint(touchLocation)
        if (node.name == "arrowDx") {
            leftPressed = false
        }
        if (node.name == "arrowSx") {
            rightPressed = false
        }
        
    }
}


